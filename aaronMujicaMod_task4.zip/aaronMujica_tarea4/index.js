console.log(document.title)


let contenedorTarjetero = document.getElementById('contenedorTarjetero')
let input = document.getElementsByClassName('input')[0]
let contenedorCheck = document.getElementById('checkBoxes')
let data = []
let pastEvents=[]
let comingEvents=[]
let fechaActual = ""

let noresult=document.getElementById("mensaje")

console.log(data)
console.log(input)


async function optenerData(){ //funcion fetch-eada

await fetch("https://amazing-events.herokuapp.com/api/events")
  .then(response=>response.json())
  .then(res=> {
    console.log(res)
    data.push(...res.events)
    fechaActual=res.currentDate
    comingEvents.push(...res.events.filter(data=> data.date>fechaActual))
    pastEvents.push(...res.events.filter(data=> data.date<fechaActual))  
    
    console.log((pastEvents))
    console.log((comingEvents))
    creadorDeTarjetasPast(pastEvents)
    creadorDeTarjetasUpcoming(comingEvents)
    arrayPadre(events)
               
  }
  )
}

optenerData()

function creadorDeTarjetas(array){
  contenedorTarjetero.innerHTML=''
  array.forEach(evento=> {
    let div = document.createElement('div')
    div.className = 'card mb-3'
    div.style.width = '18rem '
    div.innerHTML +=
    `
      <img src="${evento.image}" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">${evento.name}</h5>
        <p class="card-text">${evento.description}</p>
      </div>
      <ul class="list-group list-group-flush">
        <li class="list-group-item">${evento.category}</li>
        <li class="list-group-item">${evento.place}</li>
        <li class="list-group-item">${evento.price} $</li>
        <a href="./details.html?id=${evento._id}" class="link btn btn-primary">See more</a>

      </ul>
        
    `
    
    contenedorTarjetero.appendChild(div)
  })

}



function creadorDechecks(array)  {
  let categorias=[]

   categorias = array.map(eventos => eventos.category)
    categorias = new Set (categorias)
    categorias = Array.from(categorias)

    console.log(categorias)
    categorias.forEach(card=>{
    let div=document.createElement('div')
    div.setAttribute('class', "DIV")
    div.className='DIV d-flex'
    div.innerHTML=`
    <input  class='align-self-center' type='checkbox' checkbox id="${card}" value=${card}> 
    <label class="labels" for="${card}">${card}</label> 
    `

  
    contenedorCheck.appendChild(div)
  })


}

function arrayPadre(array){
  let contenedorPadre=[]
  let arrayHijo1=array.map(array => array={name:array.name, percentage:(array.assistance*100/array.capacity)}).filter(posicion=>posicion.percentage)
  arrayHijo1=arrayHijo1.sort((a,b) => a.percentage-b.percentage)
  console.log(arrayHijo1)

  let arrayHijo2=array.map(array => array={capacity:array.capacity,name:array.name}).sort((a,b)=> a.capacity-b.capacity)
  
  contenedorPadre.push(arrayHijo1,arrayHijo2)
  
  let creacionTabla=document.createElement("tr")
  creacionTabla.className = ("border border-2 border-dark text-dark")
  creacionTabla.innerHTML= ` 
  <td>${contenedorPadre[0][contenedorPadre[0].length-1].name}</td>
  <td>${contenedorPadre[0][0].name}</td>
  <td>${contenedorPadre[1][contenedorPadre[1].length-1].name}</td>
  `
  primeraTabla.appendChild(creacionTabla)

  console.log(contenedorPadre)
}

function creadorDeTarjetasUpcoming(array){

  let contenedorPadre=[]
  let reducido=[]
  let contenedorCategorias=array.map(categoria=>categoria.category)
  contenedorCategorias=new Set(contenedorCategorias)
  contenedorCategorias=Array.from(contenedorCategorias)

  contenedorPadre=contenedorCategorias.map(posicion => posicion=[])
  
  for(let i=0; i<array.length;i++){
      
      a = contenedorCategorias.findIndex(contenedorCategorias => contenedorCategorias === array[i].category)
      contenedorPadre[a].push(array[i])      
  }

  
      reducido=contenedorPadre.map(posicion =>posicion.map(posicion => 
      posicion={category: posicion.category, revenues: posicion.price*posicion.estimate, perAttendEst:posicion.estimate*100/posicion.capacity }))
 
  


  let reduceRevenues = reducido.map(position=>position.reduce((a,b)=>{return a+b.revenues},0))
  
  let reducePAttendance = reducido.map(position=>position.reduce((a,b)=>{return (a+b.perAttendEst)/position.length},0))
  
  let reduceCategoria =  reducido.map(position => position[0].category)

  let contenedorAbuelo=[]    

  let objeto={}

  for(let i=0; i<reduceCategoria.length;i++){
      let objeto={category:reduceCategoria[i],revenues:reduceRevenues[i],pAttendance:reducePAttendance[i]}
      contenedorAbuelo.push(objeto)
      
  }
  console.log(contenedorAbuelo)
  contenedorAbuelo.forEach( item=>{
  let tabla=document.createElement('tr')
  tabla.className=("border border-2 border-dark text-dark")
  tabla.innerHTML+=
  ` 
      <td>${item.category}</td>
      <td>${item.revenues} $</td>
      <td>${item.pAttendance} %</td>

  `
  segundaTabla.appendChild(tabla)
  })




}

function creadorDeTarjetasPast(array){

  let contenedorPadre=[]
  let reducido=[]
  let contenedorCategorias=array.map(categoria=>categoria.category)
  contenedorCategorias=new Set(contenedorCategorias)
  contenedorCategorias=Array.from(contenedorCategorias)

  contenedorPadre=contenedorCategorias.map(posicion => posicion=[])
  
  for(let i=0; i<array.length;i++){
      
      a = contenedorCategorias.findIndex(contenedorCategorias => contenedorCategorias === array[i].category)
      contenedorPadre[a].push(array[i])      
  }

  // if( currentDate<array.date){
  //     reducido=contenedorPadre.map(posicion =>posicion.map(posicion => 
  //     posicion={category: posicion.category, revenues: posicion.price*posicion.estimate, perAttendEst:posicion.estimate*100/posicion.capacity }))
  // }
  // else if(currentDate>=array.date){
  reducido=contenedorPadre.map(posicion => posicion.map(posicion => 
  posicion = {category: posicion.category , revenues:posicion.price*posicion.assistance ,
  pAttendance : posicion.assistance*100/posicion.capacity } ))


  let reduceRevenues = reducido.map(position=>position.reduce((a,b)=>{return a+b.revenues},0))
  
  let reducePAttendance = reducido.map(position=>position.reduce((a,b)=>{return (a+b.pAttendance)/position.length},0))
  
  let reduceCategoria =  reducido.map(position => position[0].category)

  let contenedorAbuelo=[]    

  let objeto={}

  for(let i=0; i<reduceCategoria.length;i++){
      let objeto={category:reduceCategoria[i],revenues:reduceRevenues[i],pAttendance:reducePAttendance[i]}
      contenedorAbuelo.push(objeto)
      
  }
  console.log(contenedorAbuelo)
  contenedorAbuelo.forEach( item=>{
  let tabla=document.createElement('tr')
  tabla.className=("border border-2 border-dark text-dark")
  tabla.innerHTML+=
  ` 
      <td>${item.category}</td>
      <td>${item.revenues} $</td>
      <td>${item.pAttendance} %</td>

  `
  terceraTabla.appendChild(tabla)
  })


}



setTimeout(()=>{

  console.log(pastEvents)
  console.log(comingEvents)
  if(document.title==='HOME'||document.title==='UPCOMING EVENTS'||document.title==='PAST EVENTS'){

  creadorDechecks(data)

  }
  let  checkboxes=Array.from(document.querySelectorAll("input[checkbox]")) 
  console.log(checkboxes)


 
  function eventos(array){
    setTimeout(()=>{
      creadorDeTarjetas(array)
  
      checkboxes.forEach(check => {
      check.addEventListener('change', ()=>{
      cruzarFiltros(array)
      } )
      }
      )
      input.addEventListener('keyup',()=>{
     
      cruzarFiltros(array)
     }
     )

    
    },2000)

    
  }

  if(document.title ==='HOME'){
   eventos (data)
    
  }
  if(document.title ==='UPCOMING EVENTS'){
    eventos (comingEvents)
  }
  if(document.title==='PAST EVENTS'){
    eventos (pastEvents)
  }
  if(document.title==='DETAILS'){

    const queryString = location.search
    const params = new URLSearchParams(queryString)
    const id = params.get("id")
    console.log(id)

    const tarjeta = data.find(evento => evento._id == id)
    console.log([location])

    let div = document.createElement('div')
    div.className = 'card mb-3'
    div.style.width = '18rem '
    div.innerHTML =
    `
      <img src="${tarjeta.image}" class="card-img-top" alt="...">
      <div class="card-body">
        <h3 class="card-title text-dark">${tarjeta.name}</h3>
        <p class="card-text">${tarjeta.description}</p>
      </div>
      <ul class="list-group list-group-flush">
        <li class="list-group-item">Category of event: ${tarjeta.category}</li>
        <li class="list-group-item">Place of event: ${tarjeta.place}</li>
      </ul>
      <h3 class="card-text text-dark">Price: ${tarjeta.price} $</h3>
    `
    
    contenedorTarjetero.appendChild(div)

  }
  
  if(document.title==='STATS'){
    let events=[]
    let currentDate=[]
    let eventStatics=[]
    let comingEvents=[]
    let pastEvents=[]
    let primeraTabla=document.getElementById("tabla")
    let segundaTabla=document.getElementById("segundaTabla")
    let terceraTabla=document.getElementById("terceraTabla")
  }

  function filtroCheck(array){
    console.log(checkboxes)
    let seleccionados= checkboxes.filter(check=> check.checked).map(check => check.id)
  
   

    if (seleccionados.length>0){
      let eventosFiltrados = array.filter(tarjetita => seleccionados.includes(tarjetita.category))
      console.log(seleccionados)
      return eventosFiltrados
    }
    return array
  }
  
  function filtroSearch(array){
    let busqueda=array.filter(elemento=>elemento.name.toLowerCase().includes(input.value.toLowerCase())||
    elemento.category.toLowerCase().includes(input.value.toLowerCase()))
  
    if(busqueda.length>0){
      return busqueda
    }
    else{
      noResults()
      return []

    }
     
  }
  
  function cruzarFiltros(array){

  let filtro1 = filtroSearch(array,input.value) 
  let filtro2 = filtroCheck(filtro1)
  
  creadorDeTarjetas(filtro2)
  }
  
  function noResults(){
  
  noresult.textContent=`
  no se encuentra dicho elemento pruebe nuevamente  
  `
  
}


}
,1000)






